# upload_file_python
Uploading files using Python and Flask

This is a simple python script to upload file or files to server using Flask.
The script lacks CSS and styling features as it is meant for illustration and getting started purposes

####Update:
- app_display_image.py: is updated code to display uploaded images. 

####Usage: 
- Best used with app.py
- Using app_basic.py implements just a basic upload without any further mods like displaying uploaded image and such.
- If using app_display_image.py Change the html file in templates folder to complete.html.
- To change the file uploaded name just make the changes; in the destination string within the code.

This code is best complemented with the video tutorials in my channel here: https://www.youtube.com/playlist?list=PL-cS6ZwDCr6rPTisIHeGtUfzN0L3USZIc

