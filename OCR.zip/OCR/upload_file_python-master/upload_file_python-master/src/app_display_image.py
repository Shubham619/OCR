import os
#from uuid import upip uid4
from uuid import uuid4
import cv2
import re

import pytesseract
pytesseract.pytesseract.tesseract_cmd= r'C:\\Program Files\\Tesseract-OCR\\tesseract.exe'
from PIL import Image, ImageEnhance
from pdf2image import convert_from_path, convert_from_bytes
from pdf2jpg import pdf2jpg
from flask import Flask, request, render_template, send_from_directory
import pandas as pd
__author__ = 'shubham'

app = Flask(__name__)
# app = Flask(__name__, static_folder="images")

  
APP_ROOT = os.path.dirname(os.path.abspath(__file__))

@app.route("/")
def index():
    return render_template("upload.html")
filename='adasdasd'








def extract_text(path): 
    img = cv2.imread(path)
    #resize the image
    img = cv2.resize(img, None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC)
    #convert the image to gray
    img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    t=pytesseract.image_to_string(img,config=r'C:\\Program Files\\Tesseract-OCR\\tesseract.exe')
    #t=extract_text('Documents\\Shubham Deshmukh_Pancard.png')
    text1=t.split("\n")

    text=[]
    for i in range(0,len(text1)):
        if len(text1[i])>1:
            text.append(text1[i])

    pan_details=[]
    for i in text:
        if len(re.findall('[^INCOME TAX DEPARTMENT]([A-Z]{2,}\s[A-Z]{0,}\s[A-Z]{2,})',i))==1:
            pan_details.append(re.findall('([A-Z]{2,}\s[A-Z]{0,}\s[A-Z]{2,})',i)[0])
        if len(re.findall('[^INCOME TAX DEPARTMENT]([A-Z]{2,}\s[A-Z]{0,}\s[A-Z]{2,})',i))==1:
            pan_details.append(re.findall('([A-Z]{2,}\s[A-Z]{0,}\s[A-Z]{2,})',i)[0])
        if len(re.findall('[A-Z]{5}[0-9]{4}[A-Z]{1}',i))==1:
            pan_details.append(re.findall('[A-Z]{5}[0-9]{4}[A-Z]{1}',i)[0])
        if len(re.findall('[0-9]{1,}\/[0-9]{1,}\/[0-9]{4}',i))==1:
            pan_details.append(re.findall('[0-9]{1,}\/[0-9]{1,}\/[0-9]{4}',i)[0])
      
    pan_details2=[]
    pan_details2.append(pan_details[0])
    pan_details2.append(pan_details[2])
    pan_details2.append(pan_details[4])
    pan_details2.append(pan_details[5])
    
    
    return(pan_details2)
    

def adhaar_back(path):
    text1=find_doc1(path)
    text_joined=" ".join(text1)
    adhaar_b=re.findall('[a-zA-Z0-9-\-]{0,}',str(re.findall('Address.*[0-9]{6}',text_joined)))
    adhaar_b_detail=[]
    for i in adhaar_b:
        if len(i)>1:
            adhaar_b_detail.append(i)
    adhaar_b_detail=adhaar_b_detail[1:]
    adhaar_b_details=' '.join(adhaar_b_detail)
    return(adhaar_b_details)

def passport(path):
    im = Image.open(path)
    enhancer = ImageEnhance.Brightness(im)
    factor = 2 
    im_output = enhancer.enhance(factor)
    factor = 2.0
    im_output = enhancer.enhance(factor)
    factor = 0.2
    im_output = enhancer.enhance(factor)
    t=pytesseract.image_to_string(im_output,lang='eng',config=r'C:\\Program Files\\Tesseract-OCR\\tesseract.exe')
    text1=t.split("\n")
    return(text1)
def find_doc(path):
    im = Image.open(path)
    enhancer = ImageEnhance.Brightness(im)
    factor = 1 
    im_output = enhancer.enhance(factor)
    factor = 2.0
    im_output = enhancer.enhance(factor)
    factor = 0.5
    im_output = enhancer.enhance(factor)

    t=pytesseract.image_to_string(im_output,lang='eng',config=r'C:\\Program Files\\Tesseract-OCR\\tesseract.exe')
    text1=t.split("\n")
    return(text1) 
def passport_front(path):    
    text1=passport(path)
    cleaned_text=[]
    for i in text1:
        if len(i)>1:
            cleaned_text.append(i)

    cleaned_text2=[]
    add=[]

    for i in range(0,len(cleaned_text)):
        if (len(re.findall("Surname",cleaned_text[i]))==1):
            cleaned_text2.append(cleaned_text[i+1])
        if (len(re.findall("Given Name",cleaned_text[i]))==1):
            cleaned_text2.append(cleaned_text[i+1])
        if (len(re.findall("Nationality",cleaned_text[i]))==1):
            cleaned_text2.append(cleaned_text[i+1])
        if (len(re.findall("Date of Issue",cleaned_text[i]))==1):  
            add.append(cleaned_text[i:i+10])

    sur_name=(re.findall('[A-Z]{2,}',cleaned_text2[0]))[0]
    given_name=(re.findall('([A-Z]{2,}\s[A-Z]{2,})|([A-Z]{2,}\s[A-Z]{2,}\s[A-Z]{2,})',cleaned_text2[1]))[0]
    nationality=(re.findall('([A-Z]{2,})',cleaned_text2[2]))[0]
    gender=(re.findall('M|F',cleaned_text2[2]))[0]
    dob=(re.findall('[0-9]{1,}\/[0-9]{1,}\/[0-9]{4}',cleaned_text2[2]))[0]
    given_name=given_name[0]

    import itertools
    add=list(itertools.chain(*add))

    dt_exp=(re.findall('[0-9]{1,}\/[0-9]{1,}\/[0-9]{4}',add[1]))
    date_issue=dt_exp[0]
    date_expiry=dt_exp[1]


    add1=[]
    for i in add:
        if len(re.findall('[A-Z]{1}[0-9]{7}',str(i)))==1:
            add1.append(re.findall('[A-Z]{1}[0-9]{7}',str(i)))

    passport_no=add1[0][0]
    return(sur_name,given_name,nationality,gender,dob,date_issue,date_expiry,passport_no)


def passport_back(path):
    text1=passport(path)
    cleaned_text=[]
    for i in text1:
        if len(i)>1:
            cleaned_text.append(i)
    cleaned_text2=[]
    add=[]

    for i in range(0,len(cleaned_text)):
        if (len(re.findall("Father.*",cleaned_text[i]))==1):
            cleaned_text2.append(cleaned_text[i+1])
        if (len(re.findall("Mother.*",cleaned_text[i]))==1):
            cleaned_text2.append(cleaned_text[i+1])
        if (len(re.findall("Spouse.*",cleaned_text[i]))==1):
            cleaned_text2.append(cleaned_text[i+1])
        if (len(re.findall("Address.*",cleaned_text[i]))==1):  
            add.append(cleaned_text[i:i+10])

    father_n=(re.findall('[A-Z]{2,}\s[A-Z]{2,}\s[A-Z]{2,}|[A-Z]{2,}\s[A-Z]{2,}',cleaned_text2[0]))[0]
    mother_n=(re.findall('[A-Z]{2,}\s[A-Z]{2,}\s[A-Z]{2,}|[A-Z]{2,}\s[A-Z]{2,}',cleaned_text2[1]))[0]
    spouse_n=(re.findall('[A-Z]{2,}\s[A-Z]{2,}\s[A-Z]{2,}|[A-Z]{2,}\s[A-Z]{2,}',cleaned_text2[2]))[0]

    import itertools
    add=list(itertools.chain(*add))

    address_cl=' '.join(add)
    address_cl=re.findall("(Address.*INDIA)",address_cl)

    address_cl2=re.findall("[A-Z]{3,}|[A-Z]\s[0-9]{1,}|[0-9]\s[A-Z]{1,}|[A-Z]\-[0-9]{1,}|[0-9]\-[A-Z]{1,}|\:|[0-9]{4,}",address_cl[0])

    address=" ".join(address_cl2)

    return(father_n,mother_n,spouse_n,address)


def find_doc1(path):
    im = Image.open(path)
    enhancer = ImageEnhance.Brightness(im)
    factor = 1 
    im_output = enhancer.enhance(factor)
    factor = 2.0
    im_output = enhancer.enhance(factor)
    factor = 0.5
    im_output = enhancer.enhance(factor)

    t=pytesseract.image_to_string(im_output,lang='eng+hin+mar',config=r'C:\\Program Files\\Tesseract-OCR\\tesseract.exe')
    text1=t.split("\n")
    return(text1)     
    
 
def image_tuning_front(path):
    im = Image.open(path)
    #im = Image.open("Documents\\adhar_sumeet.jpg")
    #im = Image.open("Documents\\Shubham Deshmukh_Adhaar Card_001.png")
    enhancer = ImageEnhance.Brightness(im)
    factor = 1 
    im_output = enhancer.enhance(factor)
    factor = 2.9
    im_output = enhancer.enhance(factor)
    factor = 0.5
    im_output = enhancer.enhance(factor)

    t=pytesseract.image_to_string(im_output,lang='eng',config=r'C:\\Program Files\\Tesseract-OCR\\tesseract.exe')
    text1=t.split("\n")

    text=[]
    for i in range(0,len(text1)):
        if len(text1[i])>1:
            text.append(text1[i])
    adhaar_f_details=[]
    for i in text:
        if len(re.findall('([0-9]{4}\s[0-9]{4}\s[0-9]{4})',i))==1:
            adhaar_f_details.append(re.findall('([0-9]{4}\s[0-9]{4}\s[0-9]{4})',i)[0])
        if len(re.findall('[A-Z]{1}[a-z]{1,}\s[A-Z]{1}[a-z]{2,}\s[A-Z]{1}[a-z]{2,}',i))==1:
            adhaar_f_details.append(re.findall('[A-Z]{1}[a-z]{1,}\s[A-Z]{1}[a-z]{2,}\s[A-Z]{1}[a-z]{2,}',i)[0])
        if len(re.findall('Male|Female|MALE|FEMALE',i))==1:
            adhaar_f_details.append(re.findall('Male|Female|MALE|FEMALE',i)[0])
        if len(re.findall('[0-9]{1,}\/[0-9]{1,}\/[0-9]{4}',i))==1:
            adhaar_f_details.append(re.findall('[0-9]{1,}\/[0-9]{1,}\/[0-9]{4}',i)[0])
    return(adhaar_f_details)

@app.route("/upload", methods=["POST"])

def upload():
    target = os.path.join(APP_ROOT, 'images and pdfs/')
  
    if not os.path.isdir(target):
            os.mkdir(target)
    else:
        print("Couldn't create upload directory: {}".format(target))
    print(request.files.getlist("file"))
    for upload in request.files.getlist("file"):
        print(upload)
        print("{} is the file name".format(upload.filename))
    
        filename = upload.filename
        destination = "/".join([target, filename])
        print ("Accept incoming file:", filename)
        print ("Save it to:", destination)
        upload.save(destination)
        os.chdir(target)
        k=filename.split('.')
        type=k[1]
        if (type=='pdf'):
            print("Yes")
        
        else:
            text_t=find_doc(filename)
            r = re.compile("Address")
            newlist = list(filter(r.findall, text_t))
            
            ca=re.compile('INCOME TAX DEPARTMENT')
            if len(list(filter(ca.findall,text_t)))>0:
                values=extract_text(filename)
                b=values[0].split(' ')
                b1=b[0]+"_"+b[2]
                b1=b1+"_"+("PAN-details")+".xlsx"
                field_names=['Name',"DOB","Gender","UID"]
                fields=pd.DataFrame(field_names)
                values=pd.DataFrame(values)
                dfa=pd.concat([fields,values],axis=1)
                dfa.columns=(["Field","Value"])
                dfa.to_excel(b1,sheet_name='PAN_details')
            
            
            ca=re.compile('Nationality')      
            if  len(list(filter(ca.findall,text_t)))>0:        
                values=passport_front(filename)
                values=list(values)
                print(values)
                b=values[1].split(' ')
                print(b)
                b1=b[0]+"_"+b[1]
                b1=b1+"_"+("Passport_Details")+".xlsx"
                field_names=['Surname',"Given_Name","Nationality","Gender","DOB","Date_issue","Date_expiry","Passport_No"]
                fields=pd.DataFrame(field_names)
                values=pd.DataFrame(values)
                dfa=pd.concat([fields,values],axis=1)
                dfa.columns=(["Field","Value"])
                dfa.to_excel(b1,sheet_name='Passport_Details')
                    
             
            ca=re.compile('Name of Father')      
            if  len(list(filter(ca.findall,text_t)))>0:        
                values=passport_back(filename)        
                b=values[1].split(' ')
                b1=b[0]+"_"+b[1]
                b1=b1+"_"+("Passport_Details")+".xlsx"
                field_names=["Father's Name","Mother's Name","Spouse_Name","Address"]
                fields=pd.DataFrame(field_names)
                values=pd.DataFrame(values)
                dfa=pd.concat([fields,values],axis=1)
                dfa.columns=(["Field","Value"])
                dfa.to_excel(b1,sheet_name='Passport_Details')
            

            ca=re.compile('([0-9]{4}\s[0-9]{4}\s[0-9]{4})')      
            if  len(list(filter(ca.findall,text_t)))>0 and (len(newlist)==0):            
                values=image_tuning_front(filename)
                b=values[0].split(' ')
                b1=b[0]+"_"+b[2]
                b1=b1+"_"+("Adhaar-details")+".xlsx"
                field_names=['Name',"DOB","Gender","UID"]
                fields=pd.DataFrame(field_names)
                values=pd.DataFrame(values)
                dfa=pd.concat([fields,values],axis=1)
                dfa.columns=(["Field","Value"])
                dfa.to_excel(b1,sheet_name='Adhaar_details')
                for j in text_t:
                    if(len(re.findall('[0-9]{4}\s[0-9]{4}\s[0-9]{4}',j))==1):
                        uid=re.findall('[0-9]{4}\s[0-9]{4}\s[0-9]{4}',j)
                        uid=uid[0]
                arr = os.listdir()
                for i in arr :
                    fl=i.split('.')[0]
                    print(fl)
                    if fl==uid:
                        
                        file=pd.read_excel(i)
                        address=file.loc[4,'Value']
                        field=file.loc[4,'Field']
                        dfa.loc[4,'Value']=address
                        dfa.loc[4,'Field']=field
                        dfa.to_excel(b1,sheet_name='Adhaar_details')
                        os.remove(i)
                    
                
            if (len(newlist)==1):
                add=adhaar_back(filename)
                    
                uid=0
                for j in text_t:
                        
                    if(len(re.findall('[0-9]{4}\s[0-9]{4}\s[0-9]{4}',j))==1):
                        uid=re.findall('[0-9]{4}\s[0-9]{4}\s[0-9]{4}',j)
                        uid=uid[0]
                            
                arr = os.listdir()
                v='Blank'
                
                    
                for i in arr :
                    if (i.endswith("xlsx")):
                        file=pd.read_excel(i)
                        if (uid!=0):
                            if(str(file['Value'][3]))==str(uid):
                                file.loc[4,'Value']=add
                                file.loc[4,'Field']="Address"
                                b=file.loc[0,'Value'].split(' ')
                                b1=b[0]+"_"+b[2]
                                b1=b1+"_"+("Adhaar-details")+".xlsx"
                                file.to_excel(b1,sheet_name='Adhaar_details')
                                    #os.remove("ChangedFile.csv")
                                v="Present"
                        print(uid)
                        if (uid==0):
                            print(uid)
                            dfObj = pd.DataFrame(columns=['Field', 'Value'], index=[0,1,2,3,4])
                            dfObj.loc[4,'Value']=add
                            dfObj.loc[4,'Field']='Address'
                            filef="Unamed"+'.xlsx'
                            dfObj.to_excel(filef,sheet_name='Adhaar_details')
                            
                    
                for i in arr:
                    if v=="Blank" and uid!=0:
                        dfObj = pd.DataFrame(columns=['Field', 'Value'], index=[0,1,2,3,4])
                        dfObj.loc[4,'Value']=add
                        dfObj.loc[4,'Field']='Address'
                        filef=uid+'.xlsx'
                        dfObj.to_excel(filef,sheet_name='Adhaar_details')
                                    
                    
                
          
            
   
        
    # return send_from_directory("images", filename, as_attachment=True)
    return render_template("complete.html", image_name=filename)




#values=extract_text(destination)


  
@app.route('/upload/<filename>')
def send_image(filename):
   
    return send_from_directory("images and pdfs", filename)


   
    
    
if __name__ == "__main__":

  
    app.run(port=4555, debug=True)
    
